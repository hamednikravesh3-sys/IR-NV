# وضعیت پیاده‌سازی v0.1

| قابلیت | وضعیت |
|---|---|
| Android 10+ project | آماده |
| Kotlin + Compose پایه | آماده |
| RTL Persian UI | آماده |
| Search UI + clear X | آماده |
| NV Code repository contract | آماده |
| NV Smart Route scoring core | آماده |
| Route alternatives UI | آماده |
| Foreground navigation service | آماده |
| MapLibre rendering | Adapter آماده، اتصال SDK لازم |
| Iran offline map download | طراحی معماری، داده/Downloader لازم |
| Valhalla offline routing | Adapter آماده، native/data integration لازم |
| GPS + sensor map matching | Contract آماده، implementation لازم |
| Live traffic | provider/backend لازم |
| Weather alerts | provider/backend لازم |
| Attractions ahead | core contract آماده، POI data لازم |
| Offline Persian voice | engine/assets لازم |
| 30-day trial | model/security design آماده، backend لازم |
| Zarinpal payment | backend callback/API credentials لازم |
| Admin gateway management | backend/admin panel لازم |
| Signed APK | نیازمند Android SDK + signing key |


## v0.3
- MapLibre Android bridge: اضافه شد
- 3D initial camera: اضافه شد
- Iran offline package manager: پایه اضافه شد
- Valhalla JNI boundary: اضافه شد
- Local style template: اضافه شد
- Real Iran data + native routing binaries: هنوز نیازمند دیتاست و build environment است
