# NV v0.3 — MapLibre + Offline Iran Integration

## What changed
- Real MapLibre Android view is now mounted behind the existing driving HUD.
- Initial camera is Tehran with 3D pitch.
- IranOfflinePackageManager added for app-scoped offline package downloads.
- Offline package model includes map, Valhalla graph, search index, POI and Persian voice assets.
- Valhalla native bridge/JNI boundary is defined.
- Offline download onboarding screen scaffold added.
- Local style JSON template added.

## Production data pipeline still required
1. Acquire/prepare legal Iran map data.
2. Build vector tiles or compatible offline tile package.
3. Build Valhalla routing tiles for Iran.
4. Build search/POI index with stable NV Codes.
5. Host a signed manifest and data packages.
6. Add SHA-256 verification + resumable downloads + WorkManager.
7. Compile/integrate Valhalla native binaries for Android ABIs.
8. Replace demo online MapLibre style URI with local style and local tile source.

## Important
MapLibre is a renderer, not a map-data license. Satellite imagery, live traffic and commercial POI
providers require separate licensed data sources.
