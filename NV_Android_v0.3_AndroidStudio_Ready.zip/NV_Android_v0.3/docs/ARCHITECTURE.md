# معماری مرجع NV

## Modules
- Map: MapLibre adapter, styles, camera, 2D/3D, terrain/satellite providers
- Offline: Iran packages, routing graph, POI/search/voice package manager
- Routing: Valhalla adapter + NV Smart Route scorer
- GPS: fused location + sensor fusion + map matching
- Guidance: maneuvers, lane guidance, junction view, speed limit
- Traffic: live/historical speed, incidents, closures, roadworks
- Search: offline/online geocoder + stable NV Code index
- POI: route-ahead filters and detour scoring
- Weather: route corridor alerts
- Voice: Persian/English TTS, offline-first
- AI: ETA/traffic prediction, reranking, preferences, eco routing
- Cloud: auth, sync, maps/POI updates, subscription, payment, admin

## Offline invariant
Internet loss must not stop:
GPS, downloaded search, NV Code lookup, route calculation, turn-by-turn guidance,
basic rerouting, offline POI and offline voice assets.

## NV Code stability
NV Code must be generated at dataset-import time, persisted with a dataset version,
and never be based on mutable UI sort order. A migration table must preserve codes across map updates.

## Payment / trial
Trial begins on first verified activation. Server owns entitlement truth.
Store only signed/short-lived entitlement cache locally. Reinstall or clock changes must not reset trial.
Admin entitlement is server-authorized. Free codes are generated/revoked server-side.
