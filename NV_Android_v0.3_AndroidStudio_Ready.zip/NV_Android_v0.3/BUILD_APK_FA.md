# راهنمای ساخت APK پروژه NV

این پروژه برای Android Studio آماده شده است.

## پیش‌نیازها
- Android Studio نسخه جدید
- JDK 17 (ترجیحاً Embedded JDK خود Android Studio)
- Android SDK Platform 35
- اتصال اینترنت در اولین Gradle Sync برای دریافت وابستگی‌ها

## باز کردن پروژه
1. Android Studio را اجرا کنید.
2. گزینه **Open** را بزنید.
3. پوشه `NV_Android_v0.3` را انتخاب کنید؛ همان پوشه‌ای که فایل `settings.gradle.kts` داخل آن است.
4. اگر Android Studio درباره Gradle/JDK سؤال کرد، **JDK 17** را انتخاب کنید.
5. اجازه دهید **Gradle Sync** کامل شود.

## ساخت APK دیباگ
از منوی Android Studio:

**Build > Build Bundle(s) / APK(s) > Build APK(s)**

پس از اتمام Build، فایل معمولاً در این مسیر قرار می‌گیرد:

`app/build/outputs/apk/debug/app-debug.apk`

## ساخت از Terminal داخل Android Studio
اگر Android Studio برای پروژه Gradle wrapper ایجاد کرد، دستور زیر قابل استفاده است:

Linux/macOS:
`./gradlew assembleDebug`

Windows:
`gradlew.bat assembleDebug`

## تنظیمات پروژه
- Application ID: `com.nv.navigation`
- minSdk: 29 (Android 10)
- targetSdk: 35
- compileSdk: 35
- Java/Kotlin target: 17
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- MapLibre Android SDK: 11.5.2

## نکته Gradle Wrapper
بسته اولیه Gradle Wrapper نداشت. Android Studio می‌تواند پروژه را Import/Sync کند و Gradle مناسب را دریافت/پیکربندی کند. اگر می‌خواهید Build خط فرمان کاملاً مستقل داشته باشید، پس از اولین Sync می‌توانید Gradle Wrapper را از داخل محیط Gradle/Android Studio تولید کنید.

## MapLibre و اجرای اولیه
Style پیش‌فرض MapLibre از آدرس آنلاین demo استفاده می‌کند؛ بنابراین برای نمایش نقشه در اجرای اولیه، اینترنت لازم است. قابلیت آفلاین کامل نیازمند دیتاست/tiles مربوط به ایران است.
