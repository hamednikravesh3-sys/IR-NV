package com.nv.navigation.core.map

import android.content.Context
import android.graphics.Color
import android.view.ViewGroup
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style

/**
 * Real MapLibre bridge for Compose.
 *
 * The default style uses an online demo style URL. For production/offline,
 * replace it with a local style JSON and local tile/PMTiles/MBTiles source
 * produced for Iran.
 */
@Composable
fun MapLibreAndroidMap(
    modifier: Modifier = Modifier,
    initialLat: Double = 35.6892,
    initialLon: Double = 51.3890,
    initialZoom: Double = 12.5,
    pitch: Double = 50.0,
    bearing: Double = 0.0,
    styleUri: String = "https://demotiles.maplibre.org/style.json",
    onReady: (MapView) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current

    DisposableEffect(Unit) {
        MapLibre.getInstance(context)
        onDispose { }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            MapView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                getMapAsync { map ->
                    map.setStyle(Style.Builder().fromUri(styleUri)) {
                        map.cameraPosition = CameraPosition.Builder()
                            .target(LatLng(initialLat, initialLon))
                            .zoom(initialZoom)
                            .tilt(pitch)
                            .bearing(bearing)
                            .build()
                        onReady(this)
                    }
                }
                onCreate(null)
                onStart()
                onResume()
            }
        },
        update = { mapView ->
            // camera/state updates are driven by the navigation state holder later
        }
    )
}
