package com.nv.navigation.core.routing

import com.nv.navigation.core.model.DriverPreferences
import com.nv.navigation.core.model.RouteCandidate

data class SmartWeights(
    val time: Double = 0.34,
    val distance: Double = 0.16,
    val traffic: Double = 0.18,
    val energy: Double = 0.10,
    val roadQuality: Double = 0.08,
    val risk: Double = 0.08,
    val weather: Double = 0.06
)

class SmartRouteScorer(private val w: SmartWeights = SmartWeights()) {
    fun score(route: RouteCandidate, prefs: DriverPreferences): Double {
        val m = route.metrics
        val unpavedPenalty = if (prefs.avoidUnpaved) m.unpavedMeters * 3.0 else m.unpavedMeters
        val tollPenalty = if (prefs.avoidTolls) m.tollMeters * 5.0 else 0.0
        return w.time * m.durationSeconds +
            w.distance * (m.distanceMeters / 10.0) +
            w.traffic * m.trafficDelaySeconds +
            w.energy * m.energyScore +
            w.roadQuality * unpavedPenalty +
            w.risk * m.riskScore * 100.0 +
            w.weather * m.weatherPenalty * 100.0 +
            tollPenalty
    }

    fun rank(routes: List<RouteCandidate>, prefs: DriverPreferences): List<RouteCandidate> =
        routes.sortedBy { score(it, prefs) }
}
