package com.nv.navigation.core.search

import com.nv.navigation.core.model.NamedPlace

/**
 * NV Code rule:
 * Every named place in a specific published Iran map dataset receives one stable code.
 * Never derive the code from mutable list order at runtime.
 * A production import job persists datasetVersion + osm/object identity + nvCode.
 */
interface NVCodeRepository {
    suspend fun findByCode(code: Long): NamedPlace?
    suspend fun search(query: String, limit: Int = 20): List<NamedPlace>
    suspend fun upsertImportedPlaces(datasetVersion: String, places: List<NamedPlace>)
}

class InMemoryNVCodeRepository : NVCodeRepository {
    private val data = linkedMapOf<Long, NamedPlace>()

    override suspend fun findByCode(code: Long): NamedPlace? = data[code]

    override suspend fun search(query: String, limit: Int): List<NamedPlace> {
        val q = query.trim()
        val asCode = q.toLongOrNull()
        return data.values.asSequence()
            .filter {
                (asCode != null && it.nvCode == asCode) ||
                it.nameFa.contains(q, ignoreCase = true) ||
                (it.nameEn?.contains(q, ignoreCase = true) == true)
            }
            .take(limit)
            .toList()
    }

    override suspend fun upsertImportedPlaces(datasetVersion: String, places: List<NamedPlace>) {
        places.forEach { data[it.nvCode] = it }
    }
}
