package com.nv.navigation.core.subscription

import java.time.Instant

enum class EntitlementType { TRIAL, PAID_30_DAY, FREE_CODE, ADMIN }

data class Entitlement(
    val type: EntitlementType,
    val validUntil: Instant?,
    val serverVerifiedAt: Instant?
) {
    fun isActive(now: Instant = Instant.now()): Boolean =
        type == EntitlementType.ADMIN || validUntil?.isAfter(now) == true
}

interface EntitlementService {
    suspend fun getCurrent(): Entitlement?
    suspend fun verifyWithServer(): Entitlement
    suspend fun redeemFreeCode(code: String): Entitlement
}

/**
 * Security note:
 * Trial/payment authority belongs on NV backend.
 * Do not trust local clock, install date or a plain device ID alone.
 */
