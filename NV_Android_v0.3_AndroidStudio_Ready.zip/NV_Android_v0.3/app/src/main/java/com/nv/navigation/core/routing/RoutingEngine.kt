package com.nv.navigation.core.routing

import com.nv.navigation.core.model.DriverPreferences
import com.nv.navigation.core.model.GeoPoint
import com.nv.navigation.core.model.RouteCandidate

interface RoutingEngine {
    suspend fun calculate(
        origin: GeoPoint,
        destination: GeoPoint,
        preferences: DriverPreferences
    ): List<RouteCandidate>

    suspend fun rerouteIfMeaningfullyBetter(
        currentRoute: RouteCandidate,
        currentPosition: GeoPoint,
        destination: GeoPoint,
        preferences: DriverPreferences,
        minimumSavingSeconds: Long = 120
    ): RouteCandidate?
}

/**
 * Production adapter target:
 * - Offline: Valhalla tiles / routing graph on-device or bundled native service.
 * - Online: optional NV Cloud traffic-enhanced routing.
 * This interface prevents vendor lock-in.
 */
class ValhallaRoutingAdapter : RoutingEngine {
    override suspend fun calculate(
        origin: GeoPoint,
        destination: GeoPoint,
        preferences: DriverPreferences
    ): List<RouteCandidate> = emptyList()

    override suspend fun rerouteIfMeaningfullyBetter(
        currentRoute: RouteCandidate,
        currentPosition: GeoPoint,
        destination: GeoPoint,
        preferences: DriverPreferences,
        minimumSavingSeconds: Long
    ): RouteCandidate? = null
}
