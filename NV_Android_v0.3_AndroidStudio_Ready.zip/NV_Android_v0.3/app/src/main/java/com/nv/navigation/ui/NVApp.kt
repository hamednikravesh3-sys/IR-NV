package com.nv.navigation.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.LayoutDirection

private val NvBlue = Color(0xFF13C7FF)
private val NvDeep = Color(0xFF061A2B)
private val NvPanel = Color(0xE80B2841)
private val NvPanel2 = Color(0xF0143554)
private val NvText = Color(0xFFF2F7FA)
private val NvMuted = Color(0xFFB6C6D3)
private val NvGreen = Color(0xFF57E77A)
private val NvAmber = Color(0xFFFFBF37)
private val NvRed = Color(0xFFFF5364)

@Composable
fun NVApp() {
    MaterialTheme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            NvDriveScreen()
        }
    }
}

@Composable
private fun NvDriveScreen() {
    var query by remember { mutableStateOf("") }
    var navigationStarted by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NvDeep)
    ) {
        com.nv.navigation.core.map.MapLibreAndroidMap(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 78.dp, bottom = 116.dp),
            initialLat = 35.6892,
            initialLon = 51.3890,
            initialZoom = 13.0,
            pitch = 52.0
        )

        TopHeader(
            query = query,
            onQueryChange = { query = it },
            onClear = { query = "" }
        )

        ManeuverCard(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 128.dp)
        )

        LeftTools(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 10.dp, top = 42.dp)
        )

        RightRoutePanel(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 110.dp, end = 10.dp),
            navigationStarted = navigationStarted,
            onStart = { navigationStarted = true }
        )

        WeatherPoiRail(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 10.dp, top = 250.dp)
        )

        SpeedHud(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 12.dp, bottom = 126.dp)
        )

        TripInfoBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 12.dp, vertical = 62.dp)
        )

        BottomNav(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(10.dp)
        )
    }
}

@Composable
private fun TopHeader(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            color = Color(0xCC0C3150),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.width(110.dp)
        ) {
            Column(
                Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("NV", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Text("همراه هوشمند سفر", color = NvMuted, fontSize = 9.sp)
            }
        }

        TextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.weight(1f),
            singleLine = true,
            placeholder = { Text("نام، مکان یا NV Code را جستجو کنید…") },
            leadingIcon = { Text("⌕", fontSize = 24.sp) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .clickable { onClear() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("×", color = Color.White, fontSize = 22.sp)
                    }
                }
            },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color(0xDD123A5B),
                unfocusedContainerColor = Color(0xDD123A5B),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedPlaceholderColor = NvMuted,
                unfocusedPlaceholderColor = NvMuted
            ),
            shape = RoundedCornerShape(18.dp)
        )

        Surface(
            color = Color(0xCC0C3150),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.width(116.dp)
        ) {
            Row(
                Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("☀", fontSize = 26.sp)
                Column {
                    Text("۲۲°C", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("تهران", color = NvMuted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ManeuverCard(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.width(220.dp),
        color = Color(0xE5125A57),
        shape = RoundedCornerShape(20.dp),
        shadowElevation = 10.dp
    ) {
        Row(
            Modifier
                .border(2.dp, Color(0xFF72F4D4), RoundedCornerShape(20.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("↱", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("۵۰۰ متر", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("خروجی بعدی", color = Color.White, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun LeftTools(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ToolButton("▰", "لایه‌ها")
        ToolButton("⛽", "پمپ بنزین")
        ToolButton("🍴", "رستوران")
        ToolButton("▣", "اقامتگاه")
        ToolButton("◉", "جاهای دیدنی")
        ToolButton("•••", "بیشتر")
    }
}

@Composable
private fun ToolButton(icon: String, label: String) {
    Surface(
        color = Color(0xDD0A2942),
        shape = RoundedCornerShape(15.dp),
        modifier = Modifier.width(70.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, color = Color.White, fontSize = 20.sp)
            Text(label, color = Color.White, fontSize = 9.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun RightRoutePanel(
    modifier: Modifier = Modifier,
    navigationStarted: Boolean,
    onStart: () -> Unit
) {
    Surface(
        modifier = modifier.width(255.dp),
        color = NvPanel,
        shape = RoundedCornerShape(22.dp),
        shadowElevation = 12.dp
    ) {
        Column(
            Modifier
                .border(1.dp, Color(0xFF1F84BD), RoundedCornerShape(22.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RouteOption("مسیر پیشنهادی", "۲۸ دقیقه", "۱۴ کیلومتر", "ترافیک سبک", NvBlue)
            RouteOption("مسیر دوم", "۳۴ دقیقه", "۱۶ کیلومتر", "ترافیک متوسط", NvAmber)
            RouteOption("مسیر سوم", "۴۲ دقیقه", "۱۸ کیلومتر", "ترافیک سنگین", NvRed)

            Button(
                onClick = onStart,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = NvBlue),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    if (navigationStarted) "مسیریابی فعال" else "شروع حرکت",
                    color = Color(0xFF001522),
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
private fun RouteOption(
    title: String,
    time: String,
    distance: String,
    traffic: String,
    accent: Color
) {
    Surface(
        color = Color(0x99102943),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .border(1.dp, accent.copy(alpha = .65f), RoundedCornerShape(14.dp))
                .padding(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(accent, CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(title, color = NvMuted, fontSize = 12.sp)
            }
            Text(time, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Text("$distance  •  $traffic", color = NvMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun WeatherPoiRail(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.width(150.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        CompactInfoCard("آب‌وهوای جلوتر", "قم • بدون هشدار", "☁")
        CompactInfoCard("جاذبه نزدیک مسیر", "برج آزادی • ۸۰۰ متر", "★")
    }
}

@Composable
private fun CompactInfoCard(title: String, subtitle: String, icon: String) {
    Surface(
        color = Color(0xD90A2B47),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier.padding(9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, fontSize = 18.sp)
            Spacer(Modifier.width(6.dp))
            Column {
                Text(title, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = NvMuted, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun SpeedHud(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            color = Color(0xE6072439),
            shape = CircleShape,
            modifier = Modifier.size(88.dp)
        ) {
            Box(
                Modifier.border(3.dp, NvGreen, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("۹۲", color = NvGreen, fontWeight = FontWeight.Black, fontSize = 28.sp)
                    Text("km/h", color = Color.White, fontSize = 11.sp)
                }
            }
        }
        Surface(
            color = Color.White,
            shape = CircleShape,
            modifier = Modifier.size(48.dp)
        ) {
            Box(
                Modifier.border(5.dp, NvRed, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("100", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun TripInfoBar(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xE6072942),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            InfoStat("۱۰:۳۶", "زمان رسیدن")
            InfoStat("۲۸ دقیقه", "زمان باقی‌مانده")
            InfoStat("۱۴ کیلومتر", "مسافت تا مقصد")
            Column(horizontalAlignment = Alignment.End) {
                Text("مقصد: برج آزادی", color = Color.White, fontWeight = FontWeight.Bold)
                Text("تهران، میدان آزادی", color = NvMuted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun InfoStat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Text(label, color = NvMuted, fontSize = 9.sp)
    }
}

@Composable
private fun BottomNav(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xF20A2740),
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(
            Modifier.padding(vertical = 10.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomItem("➤", "مسیریابی", true)
            BottomItem("⌕", "جستجو", false)
            BottomItem("♡", "علاقه‌مندی‌ها", false)
            BottomItem("↝", "مسیرها", false)
            BottomItem("☁", "آب‌وهوا", false)
            BottomItem("⚙", "تنظیمات", false)
        }
    }
}

@Composable
private fun BottomItem(icon: String, label: String, selected: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = if (selected) NvBlue else NvText, fontSize = 23.sp)
        Text(
            label,
            color = if (selected) NvBlue else NvText,
            fontSize = 9.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
