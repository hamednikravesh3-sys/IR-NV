package com.nv.navigation.core.routing

import java.io.File

data class ValhallaOfflineConfig(
    val tileDirectory: File,
    val adminDirectory: File? = null,
    val timezoneDirectory: File? = null,
    val useElevation: Boolean = true
)

/**
 * Native JNI binding point.
 * The actual Valhalla engine must be compiled for Android ABIs and exposed via JNI,
 * or run as a local service if your chosen distribution supports that architecture.
 */
interface ValhallaNativeBridge {
    suspend fun route(jsonRequest: String, config: ValhallaOfflineConfig): String
}
