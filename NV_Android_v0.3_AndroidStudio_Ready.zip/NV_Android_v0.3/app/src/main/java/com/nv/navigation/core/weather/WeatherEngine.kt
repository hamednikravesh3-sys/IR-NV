package com.nv.navigation.core.weather

data class WeatherAlert(
    val areaName: String,
    val titleFa: String,
    val severity: Int,
    val startsAtEpochSec: Long?,
    val endsAtEpochSec: Long?
)

interface WeatherEngine {
    suspend fun alertsAhead(routeId: String): List<WeatherAlert>
}
