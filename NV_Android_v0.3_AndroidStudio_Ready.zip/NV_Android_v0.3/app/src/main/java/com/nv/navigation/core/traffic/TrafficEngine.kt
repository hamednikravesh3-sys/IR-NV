package com.nv.navigation.core.traffic

data class TrafficSegment(
    val roadId: String,
    val liveSpeedKph: Double?,
    val historicalSpeedKph: Double?,
    val congestionLengthMeters: Double,
    val expectedDelaySeconds: Double
)

interface TrafficEngine {
    suspend fun segmentsAhead(routeId: String): List<TrafficSegment>
}
