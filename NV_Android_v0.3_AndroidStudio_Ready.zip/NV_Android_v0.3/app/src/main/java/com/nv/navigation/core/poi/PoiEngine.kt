package com.nv.navigation.core.poi

import com.nv.navigation.core.model.GeoPoint

enum class PoiType { FUEL, EV_CHARGER, PARKING, RESTAURANT, HOSPITAL, HOTEL, ATTRACTION }

data class RouteAheadPoi(
    val id: String,
    val name: String,
    val type: PoiType,
    val point: GeoPoint,
    val detourMeters: Double
)

interface PoiEngine {
    suspend fun ahead(routeId: String, maxDetourMeters: Double = 1500.0): List<RouteAheadPoi>
}
